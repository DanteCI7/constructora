package com.example.practica3c2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.RecyclerViewHolder> {

    private ArrayList<Member> courseDataArrayList;
    private Context mcontext;
    LayoutInflater inflater;
    private View.OnClickListener listener;

    public RecyclerViewAdapter(ArrayList<Member> recyclerDataArrayList, Context mcontext) {
        this.courseDataArrayList = recyclerDataArrayList;
        this.inflater=LayoutInflater.from(mcontext);
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.card_layout, parent, false);
        view.setOnClickListener(this::onClick);
        return new RecyclerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position) {

        Member recyclerData = courseDataArrayList.get(position);
        holder.courseTV.setText(recyclerData.getName() + "\n"  + recyclerData.getEmail() +
                "\n" +recyclerData.getTelefono() +"\n" + recyclerData.getHobbies());
        holder.courseIV.setImageResource(recyclerData.getImgid());

    }

    public void setOnClickListener(View.OnClickListener listener){
        this.listener=listener;
    }
    public void onClick(View v) {
        if(listener!=null){
            listener.onClick(v);

        }
    }
    @Override
    public int getItemCount() {
        return courseDataArrayList.size();
    }
    public class RecyclerViewHolder extends RecyclerView.ViewHolder {

        private TextView courseTV;
        private ImageView courseIV;

        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);
            courseTV = itemView.findViewById(R.id.idTVCourse);
            courseIV = itemView.findViewById(R.id.idIVcourseIV);

        }

    }
}
