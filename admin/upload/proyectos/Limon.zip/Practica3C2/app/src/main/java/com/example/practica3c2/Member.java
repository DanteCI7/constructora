package com.example.practica3c2;

public class Member {

    private String name, email,fechaN,genero,direccion,telefono,hobbies;
    private int imgid, id;

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }

    public void setEmail(String email) { this.email = email; }

    public String getFechaN() { return fechaN; }

    public void setFechaN(String fechaN) { this.fechaN = fechaN; }

    public String getGenero() { return genero; }

    public void setGenero(String genero) { this.genero = genero; }

    public String getDireccion() { return direccion; }

    public void setDireccion(String direccion) { this.direccion = direccion; }

    public String getTelefono() { return telefono; }

    public void setTelefono(String telefono) { this.telefono = telefono; }

    public String getHobbies() { return hobbies; }

    public void setHobbies(String hobbies) { this.hobbies = hobbies; }

    public int getImgid() { return imgid; }

    public void setImgid(int imgid) { this.imgid = imgid; }

    public Member(int id,String name, int imgid, String email, String fechaN,String genero, String direccion, String telefono, String hobbies ) {
        this.id= id;
        this.name = name;
        this.imgid = imgid;
        this.email= email;
        this.fechaN= fechaN;
        this.genero= genero;
        this.direccion= direccion;
        this.telefono= telefono;
        this.hobbies= hobbies;
    }
}
