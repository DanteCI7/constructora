package com.example.practica3c2;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView memberArrayList;
    ArrayList<Member> listado;

    RecyclerViewAdapter ricycleAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        memberArrayList=findViewById(R.id.idCourseRV);
        listado=new ArrayList<>();

        listado.add(new Member(1,"Luis Cano Vasquez" ,R.drawable.papa,"canolaboratorista@hotmail.com","19/08/1975",
                "Masculino","Col. Nueva Sta. Cruz, 23 de Febrero, 118","412-100-8799",
                "Jugar Basquetbol"));
        listado.add(new Member(2,"Sara Guzman Campos" ,R.drawable.madre,"saralaboratorista@hotmail.com","21/09/1975",
                "Femenina","Col. Nueva Sta. Cruz, 23 de Febrero, 118","412-892-7645",
                "Escuchar Musica y Ver series"));
       listado.add(new Member(3,"Josue Isaac Cano Guzman",R.drawable.hijo,"19030242@itcelaya.edu.mx","31/03/2001",
                "Masculina","Col. Nueva Sta. Cruz, 23 de Febrero, 118","412-100-1436",
                "Jugar Basquetbol y Videojuegos"));
        listado.add(new Member(4,"Ximena Cano Guzman",R.drawable.hija,"ximenaCano@gmail.com","24/01/2005",
                "Masculina","Col. Nueva Sta. Cruz, 23 de Febrero, 118","412-110-9021",
                "Ver anime y escuchar musica"));
        listado.add(new Member(5,"Chopper",R.drawable.chopper,"No es necesario","16/09/2016",
                "Macho","Col. Nueva Sta. Cruz, 23 de Febrero, 118","412-239-1280",
                "Jugar con balones "));

        RecyclerViewAdapter adapter=new RecyclerViewAdapter(listado,this);

        GridLayoutManager layoutManager=new GridLayoutManager(this,2);

        memberArrayList.setLayoutManager(layoutManager);
        memberArrayList.setAdapter(adapter);

        GridLayoutManager gridLayoutManager=new GridLayoutManager(this,2,GridLayoutManager.VERTICAL,false);
        memberArrayList.setLayoutManager(gridLayoutManager);
        adapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Se seleciono: "+listado.get(memberArrayList.getChildAdapterPosition(v)).getName(),Toast.LENGTH_SHORT).show();
                showProductDetailsDialog(listado.get(memberArrayList.getChildAdapterPosition(v)));

            }
        });
       memberArrayList.setAdapter(adapter);
    }
    private void showProductDetailsDialog(Member miembro){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Members Details");
        //builder.setMessage("Her goes product details....");
        View view = getLayoutInflater().inflate(R.layout.member_details,null);
        builder.setView(view);
        ImageView imagen = view.findViewById(R.id.image);
        TextView nombre = view.findViewById(R.id.nombre);
        TextView correo = view.findViewById(R.id.txtCorreo);
        TextView fecha = view.findViewById(R.id.txtFecha);
        TextView genero = view.findViewById(R.id.genero);
        TextView direccion = view.findViewById(R.id.txtDireccion);
        TextView telefono = view.findViewById(R.id.txtTelefono);
        TextView hobbie = view.findViewById(R.id.txtHobbie);

        imagen.setImageResource(miembro.getImgid());
        nombre.setText(miembro.getName());
        correo.setText(miembro.getEmail());
        fecha.setText(miembro.getFechaN());

        direccion.setText(miembro.getDireccion());
        telefono.setText(miembro.getTelefono());
        hobbie.setText(miembro.getHobbies());
        genero.setText(miembro.getGenero());
        builder.setPositiveButton("Ok", null);
        builder.setNegativeButton("Cancel", null);
        Dialog dialog = builder.create();
        dialog.show();
    }
}