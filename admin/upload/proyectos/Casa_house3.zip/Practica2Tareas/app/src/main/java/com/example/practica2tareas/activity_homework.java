package com.example.practica2tareas;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class activity_homework extends AppCompatActivity {
EditText editHomework;
Button registerHomework,mostrarHW;
   ArrayList<String> homeworkList= new ArrayList<>();
@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homework);
        editHomework=findViewById(R.id.EditHomework);
        registerHomework=findViewById(R.id.RegisterHomework);
        mostrarHW= findViewById(R.id.MostrarHW);

        registerHomework.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            homeworkList.add(editHomework.getText().toString());
                Toast.makeText(activity_homework.this,"Registro exitoso!!",Toast.LENGTH_LONG).show();
            }
        });
        mostrarHW.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(activity_homework.this,activity_list.class);
               intent.putExtra("hwlist",homeworkList);
                startActivity(intent);
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.menu_exit:
                finish();
                break;

        }
        return super.onOptionsItemSelected(item);
    }

}