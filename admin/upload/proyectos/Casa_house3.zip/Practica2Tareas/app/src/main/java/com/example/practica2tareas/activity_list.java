package com.example.practica2tareas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.sql.Array;
import java.util.ArrayList;

public class activity_list extends AppCompatActivity {
ListView list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        list= findViewById(R.id.list);
        ArrayList hwlist= getIntent().getStringArrayListExtra("hwlist");

        ArrayAdapter arrayAdapter= new ArrayAdapter(this, android.R.layout.simple_list_item_checked,hwlist);
        list.setAdapter(arrayAdapter);
        list.setChoiceMode(2);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(parent.getContext(),"Haz seleccionado " +parent.getItemAtPosition(position).toString(),Toast.LENGTH_LONG).show();
            }
        });
    }
}