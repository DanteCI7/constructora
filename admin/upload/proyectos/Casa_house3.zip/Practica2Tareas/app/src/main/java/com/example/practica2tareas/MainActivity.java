package com.example.practica2tareas;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;


public class MainActivity extends AppCompatActivity {
    EditText UserName,PasswordJoin;
    Button RegisterJoin,login;
    String userName,userPassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RegisterJoin = findViewById(R.id.RegisterJoin);
        login= findViewById(R.id.login);
        UserName=findViewById(R.id.UserName);
        PasswordJoin=findViewById(R.id.PasswordJoin);

        RegisterJoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            Intent intent= new Intent(MainActivity.this,activity_register.class);
            startActivity(intent);
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userName=getIntent().getStringExtra("userName");
                userPassword=getIntent().getStringExtra("userPassword");
                if(UserName.getText().toString().equals(userName)&& PasswordJoin.getText().toString().equals(userPassword)){
                    Intent intent=new Intent(MainActivity.this,activity_homework.class);
                    startActivity(intent);
                    Toast.makeText(MainActivity.this,"Ingreso Exitoso",Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(MainActivity.this,"Existe un error, al ingresar datos",Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

}